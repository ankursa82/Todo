import '../App.css'
function Header(){
    return(
        <>
        <div className="nav">
            <h1>To Do List</h1>
        </div>
        </>
    )
}
export default Header;